A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/pjbJLG.

 A vanilla.js canvas confetti animation. Move the mouse to change direction.

Forked from [Linmiao Xu](http://codepen.io/linrock/)'s Pen [Falling Confetti](http://codepen.io/linrock/pen/Amdhr/).